export * from './ng4-files-click.component';
