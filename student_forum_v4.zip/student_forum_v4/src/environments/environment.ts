export const environment = {  
    production: false,
    envName: 'dev'
  };